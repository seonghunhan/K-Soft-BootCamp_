package kr.ac.inha.chap09;

public class Boricha extends Beverage{
}
