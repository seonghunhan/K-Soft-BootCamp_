package kr.ac.inha.chap09;

public class Beer extends Beverage{
}
