package kr.ac.inha.chap09;

public class Fuel{
}
