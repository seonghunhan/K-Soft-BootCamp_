package kr.ac.inha.chap07;

public class Bird {
	void move() {
		System.out.println("새가 움직인다~~~.");
	}

	void sound() {
	}
}

// public interface Bird {
// void move();
// }