package packt;

import java.io.IOException;
import java.io.PrintWriter;

public class ServletExample { //extends HttpServlet {

//    @Override
//    public void doGet(HttpServletRequest request,
//            HttpServletResponse response)
//            throws ServletException, IOException {
//        response.setContentType("text/html");
//        PrintWriter out = response.getWriter();
//        out.println("<h1>" + "Message to be sent" + "</h1>");
//    }
//
//    @Override
//    public void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws IOException, ServletException {
//        doGet(request, response);
//    }

}
