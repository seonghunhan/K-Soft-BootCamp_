package sec05;

public class Beverage {
}
