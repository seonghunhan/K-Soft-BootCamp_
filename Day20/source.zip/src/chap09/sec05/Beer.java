package sec05;

public class Beer extends Beverage {
}
