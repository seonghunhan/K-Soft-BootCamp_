package sec05;

public class Boricha extends Beverage {
}
