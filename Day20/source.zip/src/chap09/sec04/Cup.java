package sec04;

public class Cup<T extends Beverage> {

}
