package sec04;

public class Beer extends Beverage {
}
