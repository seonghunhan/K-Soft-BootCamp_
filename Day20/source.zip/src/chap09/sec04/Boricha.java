package sec04;

public class Boricha extends Beverage {
}
