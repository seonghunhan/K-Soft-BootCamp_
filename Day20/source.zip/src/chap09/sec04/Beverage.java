package sec04;

public class Beverage {
}
