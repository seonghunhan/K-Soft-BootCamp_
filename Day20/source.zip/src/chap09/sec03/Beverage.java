package sec03;

public class Beverage {
}
