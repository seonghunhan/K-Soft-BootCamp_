package sec03;

public class Boricha extends Beverage {
}
