package sec03;

public class Cup<T extends Beverage> {

}
