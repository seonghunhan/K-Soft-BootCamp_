package sec03;

public class Beer extends Beverage {
}
