package sec01;

public class CheckedDemo {
	public static void main(String[] args) {
		// Thread.sleep(100);
	}
}