package utils;

import developer.Secret;

public class Open {
	public void yahoo() {
		new Secret().hush();
	}
}
