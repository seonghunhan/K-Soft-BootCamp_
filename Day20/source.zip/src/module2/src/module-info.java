module module2 {
	exports utils;
}