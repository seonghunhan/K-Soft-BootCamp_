package developer;

public class Secret {
	public void hush() {
		System.out.println("Hi, module!");
	}
}
