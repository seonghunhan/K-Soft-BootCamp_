package sec03;

public class For1Demo {
	public static void main(String[] args) {
		for (int i = 1; i < 5; i++)
			System.out.print(i);
	}
}