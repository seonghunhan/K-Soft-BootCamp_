package sec02;

public class MathDemo {
	public static void main(String[] args) {
		System.out.println("Math.pow(2, 8) : " + Math.pow(2, 8));

		System.out.println("Math.random() : " + Math.random());

		System.out.println("Math.sin(Math.PI) : " + Math.sin(Math.PI));

		System.out.println("Math.min(10, 20) : " + Math.min(10, 20));
	}
}