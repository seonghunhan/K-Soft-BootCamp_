package sec06;

public class One1 extends One {
	void print() {
		// System.out.println(secret);
		System.out.println(roommate);
		System.out.println(child);
		System.out.println(anybody);
	}

	// void show() {
	// }
}