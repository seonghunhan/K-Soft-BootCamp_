package sec06;

public class Two {
	void print() {
		One o = new One();
		// System.out.println(o.secret);
		System.out.println(o.roommate);
		System.out.println(o.child);
		System.out.println(o.anybody);
	}
}
