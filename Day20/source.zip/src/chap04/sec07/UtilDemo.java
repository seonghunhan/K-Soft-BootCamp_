package sec07;

class Util {
	static int fourTimes(int i) {
		return i * 4;
	}
}

public class UtilDemo {
	public static void main(String[] args) {
		System.out.println(Util.fourTimes(5));
	}
}