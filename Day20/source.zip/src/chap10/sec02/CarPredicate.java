package sec02;

public interface CarPredicate {
    boolean test(Car car);
}
