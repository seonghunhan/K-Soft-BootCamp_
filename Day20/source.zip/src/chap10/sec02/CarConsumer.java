package sec02;

public interface CarConsumer {
    void apply(Car car);
}
