module module1 {
	requires module2;
}