package programmer;

// import developer.*;
import utils.Open;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Open().yahoo();
		// new Secret().hush();
	}
}
