package kr.ac.inha.chap15;

import javax.swing.*;

public class HelloSwingDemo {
    public static void main(String[] args) {
        JFrame f = new JFrame();

        f.setTitle("채팅 프로그램");
        f.setSize(300, 100);
        f.setVisible(true);
    }
}
